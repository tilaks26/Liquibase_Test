-- MySQL dump 10.15  Distrib 10.0.31-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: profile_service
-- ------------------------------------------------------
-- Server version	10.0.31-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `GATEWAY`
--

DROP TABLE IF EXISTS `GATEWAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GATEWAY` (
  `AIRAVATA_INTERNAL_GATEWAY_ID` varchar(255) NOT NULL,
  `DECLINED_REASON` varchar(255) DEFAULT NULL,
  `GATEWAY_DOMAIN` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `GATEWAY_ACRONYM` varchar(255) DEFAULT NULL,
  `GATEWAY_ADMIN_EMAIL` varchar(255) DEFAULT NULL,
  `GATEWAY_ADMIN_FIRST_NAME` varchar(255) DEFAULT NULL,
  `GATEWAY_ADMIN_LAST_NAME` varchar(255) DEFAULT NULL,
  `GATEWAY_APPROVAL_STATUS` varchar(255) DEFAULT NULL,
  `GATEWAY_ID` varchar(255) DEFAULT NULL,
  `GATEWAY_NAME` varchar(255) DEFAULT NULL,
  `GATEWAY_PUBLIC_ABSTRACT` varchar(255) DEFAULT NULL,
  `GATEWAY_URL` varchar(255) DEFAULT NULL,
  `IDENTITY_SERVER_PASSWORD_TOKEN` varchar(255) DEFAULT NULL,
  `IDENTITY_SERVER_USERNAME` varchar(255) DEFAULT NULL,
  `OAUTH_CLIENT_ID` varchar(255) DEFAULT NULL,
  `OAUTH_CLIENT_SECRET` varchar(255) DEFAULT NULL,
  `REQUEST_CREATION_TIME` bigint(20) DEFAULT NULL,
  `REQUESTER_USERNAME` varchar(255) DEFAULT NULL,
  `GATEWAY_REVIEW_PROPOSAL_DESCRIPTION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`AIRAVATA_INTERNAL_GATEWAY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GATEWAY`
--

LOCK TABLES `GATEWAY` WRITE;
/*!40000 ALTER TABLE `GATEWAY` DISABLE KEYS */;
INSERT INTO `GATEWAY` VALUES ('23624467-ead3-49b8-8b5d-e592472f19d5',NULL,NULL,NULL,NULL,'sgg@iu.edu','Admin','User','APPROVED','seagrid','Dev SEAGrid',NULL,'https://dev.seagrid.org',NULL,'admin','pga','5d2dc66a-f54e-4fa9-b78f-80d33aa862c1',1497621867014,NULL,NULL),('289471e1-95ef-4ab1-ae2f-4f2c2d34b17c',NULL,NULL,NULL,NULL,'sgg@iu.edu','Admin','User','APPROVED','scigap','Dev SciGaP',NULL,'https://dev.scigap.org',NULL,'scigap_admin','pga','b1f94742-cc59-4466-b527-3973d2c14acf',0,NULL,NULL);
/*!40000 ALTER TABLE `GATEWAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NSF_DEMOGRAPHIC`
--

DROP TABLE IF EXISTS `NSF_DEMOGRAPHIC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NSF_DEMOGRAPHIC` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) NOT NULL,
  `GENDER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`AIRAVATA_INTERNAL_USER_ID`),
  CONSTRAINT `NSF_DEMOGRAPHIC_ibfk_1` FOREIGN KEY (`AIRAVATA_INTERNAL_USER_ID`) REFERENCES `USER_PROFILE` (`AIRAVATA_INTERNAL_USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NSF_DEMOGRAPHIC`
--

LOCK TABLES `NSF_DEMOGRAPHIC` WRITE;
/*!40000 ALTER TABLE `NSF_DEMOGRAPHIC` DISABLE KEYS */;
/*!40000 ALTER TABLE `NSF_DEMOGRAPHIC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NSF_DEMOGRAPHIC_DISABILITY`
--

DROP TABLE IF EXISTS `NSF_DEMOGRAPHIC_DISABILITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NSF_DEMOGRAPHIC_DISABILITY` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) DEFAULT NULL,
  `DISABILITIES` varchar(255) DEFAULT NULL,
  KEY `AIRAVATA_INTERNAL_USER_ID` (`AIRAVATA_INTERNAL_USER_ID`),
  CONSTRAINT `NSF_DEMOGRAPHIC_DISABILITY_ibfk_1` FOREIGN KEY (`AIRAVATA_INTERNAL_USER_ID`) REFERENCES `NSF_DEMOGRAPHIC` (`AIRAVATA_INTERNAL_USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NSF_DEMOGRAPHIC_DISABILITY`
--

LOCK TABLES `NSF_DEMOGRAPHIC_DISABILITY` WRITE;
/*!40000 ALTER TABLE `NSF_DEMOGRAPHIC_DISABILITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `NSF_DEMOGRAPHIC_DISABILITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NSF_DEMOGRAPHIC_ETHNICITY`
--

DROP TABLE IF EXISTS `NSF_DEMOGRAPHIC_ETHNICITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NSF_DEMOGRAPHIC_ETHNICITY` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) DEFAULT NULL,
  `ETHNICITIES` varchar(255) DEFAULT NULL,
  KEY `AIRAVATA_INTERNAL_USER_ID` (`AIRAVATA_INTERNAL_USER_ID`),
  CONSTRAINT `NSF_DEMOGRAPHIC_ETHNICITY_ibfk_1` FOREIGN KEY (`AIRAVATA_INTERNAL_USER_ID`) REFERENCES `NSF_DEMOGRAPHIC` (`AIRAVATA_INTERNAL_USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NSF_DEMOGRAPHIC_ETHNICITY`
--

LOCK TABLES `NSF_DEMOGRAPHIC_ETHNICITY` WRITE;
/*!40000 ALTER TABLE `NSF_DEMOGRAPHIC_ETHNICITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `NSF_DEMOGRAPHIC_ETHNICITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NSF_DEMOGRAPHIC_RACE`
--

DROP TABLE IF EXISTS `NSF_DEMOGRAPHIC_RACE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NSF_DEMOGRAPHIC_RACE` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) DEFAULT NULL,
  `RACES` varchar(255) DEFAULT NULL,
  KEY `AIRAVATA_INTERNAL_USER_ID` (`AIRAVATA_INTERNAL_USER_ID`),
  CONSTRAINT `NSF_DEMOGRAPHIC_RACE_ibfk_1` FOREIGN KEY (`AIRAVATA_INTERNAL_USER_ID`) REFERENCES `NSF_DEMOGRAPHIC` (`AIRAVATA_INTERNAL_USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NSF_DEMOGRAPHIC_RACE`
--

LOCK TABLES `NSF_DEMOGRAPHIC_RACE` WRITE;
/*!40000 ALTER TABLE `NSF_DEMOGRAPHIC_RACE` DISABLE KEYS */;
/*!40000 ALTER TABLE `NSF_DEMOGRAPHIC_RACE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PROFILE`
--

DROP TABLE IF EXISTS `USER_PROFILE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PROFILE` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) NOT NULL,
  `COMMENTS` text,
  `COUNTRY` varchar(255) DEFAULT NULL,
  `CREATION_TIME` datetime DEFAULT NULL,
  `FIRST_NAME` varchar(255) DEFAULT NULL,
  `GATEWAY_ID` varchar(255) DEFAULT NULL,
  `GPG_KEY` text,
  `HOME_ORGANIZATION` varchar(255) DEFAULT NULL,
  `LAST_ACCESS_TIME` datetime DEFAULT NULL,
  `LAST_NAME` varchar(255) DEFAULT NULL,
  `MIDDLE_NAME` varchar(255) DEFAULT NULL,
  `NAME_PREFIX` varchar(255) DEFAULT NULL,
  `NAME_SUFFIX` varchar(255) DEFAULT NULL,
  `ORCID_ID` varchar(255) DEFAULT NULL,
  `ORIGINATION_AFFILIATION` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `TIME_ZONE` varchar(255) DEFAULT NULL,
  `USER_ID` varchar(255) DEFAULT NULL,
  `USER_MODEL_VERSION` varchar(255) DEFAULT NULL,
  `VALID_UNTIL` datetime DEFAULT NULL,
  PRIMARY KEY (`AIRAVATA_INTERNAL_USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PROFILE`
--

LOCK TABLES `USER_PROFILE` WRITE;
/*!40000 ALTER TABLE `USER_PROFILE` DISABLE KEYS */;
INSERT INTO `USER_PROFILE` VALUES ('admin@seagrid',NULL,NULL,'2017-06-16 15:26:06','Admin','seagrid',NULL,NULL,'2017-06-16 15:26:06','Admin',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'admin','1.0','1969-12-31 23:59:59'),('alaindomissy@scigap',NULL,'United States','2017-06-16 15:30:48','Alain','scigap',NULL,'UCSD Health','2017-06-16 15:30:48','Domissy',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'alaindomissy','1.0','1969-12-31 23:59:59'),('anujbhan@scigap',NULL,NULL,'2017-06-16 15:30:49','Anuj','scigap',NULL,NULL,'2017-06-16 15:30:49','Bhandar',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'anujbhan','1.0','1969-12-31 23:59:59'),('anujbhan@seagrid',NULL,NULL,'2017-06-16 15:26:06','Anuj','seagrid',NULL,NULL,'2017-06-16 15:26:06','Bhandar',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'anujbhan','1.0','1969-12-31 23:59:59'),('anujmb@seagrid',NULL,'United States','2017-06-16 15:26:07','anuj','seagrid',NULL,NULL,'2017-06-16 15:26:07','bhandar',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'anujmb','1.0','1969-12-31 23:59:59'),('april16@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:51','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:51','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'april16','1.0','1969-12-31 23:59:59'),('cdscigap1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:21','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:21','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'cdscigap1','1.0','1969-12-31 23:59:59'),('checkscigap1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:21','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:21','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'checkscigap1','1.0','1969-12-31 23:59:59'),('checkscigap2@scigap',NULL,'Sri Lanka','2017-06-16 15:30:22','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:22','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'checkscigap2','1.0','1969-12-31 23:59:59'),('checkscigap3@scigap',NULL,'United States','2017-06-16 15:30:22','Amila','scigap',NULL,'IU','2017-06-16 15:30:22','J',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'checkscigap3','1.0','1969-12-31 23:59:59'),('dampoi@scigap',NULL,NULL,'2017-06-16 15:30:23','Dam','scigap',NULL,NULL,'2017-06-16 15:30:23','poi',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dampoi','1.0','1969-12-31 23:59:59'),('datas1@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:59','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:59','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'datas1','1.0','1969-12-31 23:59:59'),('demogyadm@scigap',NULL,NULL,'2017-06-16 15:30:23','Demo','scigap',NULL,NULL,'2017-06-16 15:30:23','Admin',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'demogyadm','1.0','1969-12-31 23:59:59'),('demousergwy@scigap',NULL,NULL,'2017-06-16 15:30:49','Demo','scigap',NULL,NULL,'2017-06-16 15:30:49','gateway',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'demousergwy','1.0','1969-12-31 23:59:59'),('dev1eroma2017@seagrid',NULL,NULL,'2017-06-16 15:25:59','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:59','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dev1eroma2017','1.0','1969-12-31 23:59:59'),('devero2017@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:00','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:00','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'devero2017','1.0','1969-12-31 23:59:59'),('deveroma2017@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:00','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:00','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'deveroma2017','1.0','1969-12-31 23:59:59'),('devond3~@scigap',NULL,NULL,'2017-06-16 15:30:25','Alva','scigap',NULL,'Jackson State University','2017-06-16 15:30:25','Dillon',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'devond3~','1.0','1969-12-31 23:59:59'),('devscigap1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:24','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:24','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'devscigap1','1.0','1969-12-31 23:59:59'),('devscigap2@gmail.com@scigap',NULL,'United States','2017-06-16 15:30:24','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:24','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'devscigap2@gmail.com','1.0','1969-12-31 23:59:59'),('devscigap3@scigap',NULL,'Sri Lanka','2017-06-16 15:30:25','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:25','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'devscigap3','1.0','1969-12-31 23:59:59'),('devseagrid10@seagrid',NULL,'United States','2017-06-16 15:26:01','Eroma','seagrid',NULL,'Indiana Univeristy','2017-06-16 15:26:01','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'devseagrid10','1.0','1969-12-31 23:59:59'),('devseagrid1@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:01','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:01','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'devseagrid1','1.0','1969-12-31 23:59:59'),('devtest1@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:02','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:02','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'devtest1','1.0','1969-12-31 23:59:59'),('dseagrid100@seagrid',NULL,'United States','2017-06-16 15:25:51','Eroma','seagrid',NULL,'Indiana Univeristy','2017-06-16 15:25:51','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid100','1.0','1969-12-31 23:59:59'),('dseagrid101@seagrid',NULL,'United States','2017-06-16 15:25:52','Eroma','seagrid',NULL,'Indiana Univeristy','2017-06-16 15:25:52','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid101','1.0','1969-12-31 23:59:59'),('dseagrid11@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:52','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:52','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid11','1.0','1969-12-31 23:59:59'),('dseagrid200@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:53','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:53','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid200','1.0','1969-12-31 23:59:59'),('dseagrid300@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:53','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:53','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid300','1.0','1969-12-31 23:59:59'),('dseagrid500@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:54','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:54','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid500','1.0','1969-12-31 23:59:59'),('dseagrid5@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:54','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:54','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid5','1.0','1969-12-31 23:59:59'),('dseagrid6@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:55','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:55','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid6','1.0','1969-12-31 23:59:59'),('dseagrid7@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:55','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:55','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dseagrid7','1.0','1969-12-31 23:59:59'),('dsgrid1@seagrid',NULL,'United States','2017-06-16 15:25:56','Eroma','seagrid',NULL,'Indiana Univeristy','2017-06-16 15:25:56','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dsgrid1','1.0','1969-12-31 23:59:59'),('dshare1@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:56','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:56','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dshare1','1.0','1969-12-31 23:59:59'),('dshare2@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:57','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:57','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dshare2','1.0','1969-12-31 23:59:59'),('dshare3@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:58','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:58','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dshare3','1.0','1969-12-31 23:59:59'),('dshare5@seagrid',NULL,'Sri Lanka','2017-06-16 15:25:58','Eroma','seagrid',NULL,NULL,'2017-06-16 15:25:58','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'dshare5','1.0','1969-12-31 23:59:59'),('elena123@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:02','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:02','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'elena123','1.0','1969-12-31 23:59:59'),('enggateway100@scigap',NULL,'United States','2017-06-16 15:30:26','Thejaka','scigap',NULL,NULL,'2017-06-16 15:30:26','Kane',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'enggateway100','1.0','1969-12-31 23:59:59'),('enggateway16@scigap',NULL,'Sri Lanka','2017-06-16 15:30:26','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:26','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'enggateway16','1.0','1969-12-31 23:59:59'),('enggateway2015@scigap',NULL,'Sri Lanka','2017-06-16 15:30:27','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:27','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'enggateway2015','1.0','1969-12-31 23:59:59'),('enggateway2016@scigap',NULL,'Sri Lanka','2017-06-16 15:30:27','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:27','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'enggateway2016','1.0','1969-12-31 23:59:59'),('enggateway@scigap',NULL,'Sri Lanka','2017-06-16 15:30:26','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:26','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'enggateway','1.0','1969-12-31 23:59:59'),('engineergateway1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:28','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:28','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'engineergateway1','1.0','1969-12-31 23:59:59'),('eroma1802@scigap',NULL,NULL,'2017-06-16 15:30:29','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:29','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eroma1802','1.0','1969-12-31 23:59:59'),('eroma2016@scigap',NULL,NULL,'2017-06-16 15:30:29','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:29','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eroma2016','1.0','1969-12-31 23:59:59'),('eroma2017@scigap',NULL,'USA','2017-06-16 15:30:30','Eroma','scigap',NULL,'IU','2017-06-16 15:30:30','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eroma2017','1.0','1969-12-31 23:59:59'),('eroma2017@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:03','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:03','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eroma2017','1.0','1969-12-31 23:59:59'),('eromagateway17@scigap',NULL,NULL,'2017-06-16 15:30:31','Methindri','scigap',NULL,'IU','2017-06-16 15:30:31','Jayasekara',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eromagateway17','1.0','1969-12-31 23:59:59'),('eromagateway1@scigap',NULL,'United States','2017-06-16 15:30:30','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:30','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eromagateway1','1.0','1969-12-31 23:59:59'),('eromapga@scigap',NULL,'United States','2017-06-16 15:30:31','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:31','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eromapga','1.0','1969-12-31 23:59:59'),('eromasgrc@scigap',NULL,NULL,'2017-06-16 15:30:31','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:31','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eromasgrc','1.0','1969-12-31 23:59:59'),('eroscigap@scigap',NULL,'United States','2017-06-16 15:30:28','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:28','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'eroscigap','1.0','1969-12-31 23:59:59'),('gateway1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:32','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:32','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'gateway1','1.0','1969-12-31 23:59:59'),('gatewaypi1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:32','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:32','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'gatewaypi1','1.0','1969-12-31 23:59:59'),('gatewayr1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:33','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:33','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'gatewayr1','1.0','1969-12-31 23:59:59'),('gatewaytest1@scigap',NULL,NULL,'2017-06-16 15:30:49','Supun','scigap',NULL,NULL,'2017-06-16 15:30:49','Nakandala',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'gatewaytest1','1.0','1969-12-31 23:59:59'),('gemba1@scigap',NULL,NULL,'2017-06-16 15:30:50','Supun','scigap',NULL,NULL,'2017-06-16 15:30:50','Nakandala',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'gemba1','1.0','1969-12-31 23:59:59'),('goshenoy@scigap',NULL,'USA','2017-06-16 15:30:50','Gourav','scigap',NULL,'Indiana University Bloomington','2017-06-16 15:30:50','Shenoy',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'goshenoy','1.0','1969-12-31 23:59:59'),('goshenoy@seagrid',NULL,NULL,'2017-06-16 15:26:07','Gourav','seagrid',NULL,NULL,'2017-06-16 15:26:07','Shenoy',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'goshenoy','1.0','1969-12-31 23:59:59'),('hellork@scigap',NULL,NULL,'2017-06-16 15:30:51','B','scigap',NULL,NULL,'2017-06-16 15:30:51','KRISHNA',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'hellork','1.0','1969-12-31 23:59:59'),('hhcorzo@scigap',NULL,'United States','2017-06-16 15:30:51','Hector','scigap',NULL,'Auburn University','2017-06-16 15:30:51','Corzo',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'hhcorzo','1.0','1969-12-31 23:59:59'),('john123@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:03','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:03','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'john123','1.0','1969-12-31 23:59:59'),('jsale37@scigap',NULL,NULL,'2017-06-16 15:30:52','Jeff','scigap',NULL,NULL,'2017-06-16 15:30:52','Sale',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'jsale37','1.0','1969-12-31 23:59:59'),('jsgateways1@scigap',NULL,'United States','2017-06-16 15:30:33','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:33','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'jsgateways1','1.0','1969-12-31 23:59:59'),('junwang@seagrid',NULL,NULL,'2017-06-16 15:26:08','Jun','seagrid',NULL,NULL,'2017-06-16 15:26:08','Wang',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'junwang','1.0','1969-12-31 23:59:59'),('juxtapose@scigap',NULL,NULL,'2017-06-16 15:30:52','Supun','scigap',NULL,NULL,'2017-06-16 15:30:52','Nakandala',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'juxtapose','1.0','1969-12-31 23:59:59'),('mamiller@scigap',NULL,NULL,'2017-06-16 15:30:53','Mark','scigap',NULL,'sdsc','2017-06-16 15:30:53','Miller',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'mamiller','1.0','1969-12-31 23:59:59'),('marcus-user2@seagrid',NULL,NULL,'2017-06-16 15:26:09','Marcus','seagrid',NULL,NULL,'2017-06-16 15:26:09','Christie',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'marcus-user2','1.0','1969-12-31 23:59:59'),('marcus-user3@seagrid',NULL,NULL,'2017-06-16 15:26:09','Marcus','seagrid',NULL,NULL,'2017-06-16 15:26:09','Christie',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'marcus-user3','1.0','1969-12-31 23:59:59'),('marcus-user4@seagrid',NULL,NULL,'2017-06-16 15:26:10','Marcus','seagrid',NULL,NULL,'2017-06-16 15:26:10','Christie',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'marcus-user4','1.0','1969-12-31 23:59:59'),('marcus-user@seagrid',NULL,NULL,'2017-06-16 15:26:08','Marcus','seagrid',NULL,NULL,'2017-06-16 15:26:08','Christie',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'marcus-user','1.0','1969-12-31 23:59:59'),('marcus@scigap',NULL,NULL,'2017-06-16 15:30:53','Marcus','scigap',NULL,NULL,'2017-06-16 15:30:53','Christie',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'marcus','1.0','1969-12-31 23:59:59'),('marcus@seagrid',NULL,NULL,'2017-06-16 15:26:08','Marcus','seagrid',NULL,'','2017-06-16 15:26:08','Christie',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'marcus','1.0','1969-12-31 23:59:59'),('markperri@scigap',NULL,'USA','2017-06-16 15:30:54','Mark','scigap',NULL,'Sonoma State University','2017-06-16 15:30:54','Perri',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'markperri','1.0','1969-12-31 23:59:59'),('marpierc@scigap',NULL,NULL,'2017-06-16 15:30:54','Marlon','scigap',NULL,NULL,'2017-06-16 15:30:54','Pierce',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'marpierc','1.0','1969-12-31 23:59:59'),('ndoshi28@scigap',NULL,NULL,'2017-06-16 15:30:34','Nipurn','scigap',NULL,NULL,'2017-06-16 15:30:34','Doshi',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'ndoshi28','1.0','1969-12-31 23:59:59'),('newgateway100@scigap',NULL,'USA','2017-06-16 15:30:36','Eroma','scigap',NULL,'IU','2017-06-16 15:30:36','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway100','1.0','1969-12-31 23:59:59'),('newgateway10@scigap',NULL,'United States','2017-06-16 15:30:35','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:35','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway10','1.0','1969-12-31 23:59:59'),('newgateway111@scigap',NULL,NULL,'2017-06-16 15:30:37','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:37','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway111','1.0','1969-12-31 23:59:59'),('newgateway11@scigap',NULL,'United States','2017-06-16 15:30:37','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:37','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway11','1.0','1969-12-31 23:59:59'),('newgateway1@scigap',NULL,NULL,'2017-06-16 15:30:35','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:35','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway1','1.0','1969-12-31 23:59:59'),('newgateway20@scigap',NULL,'United States','2017-06-16 15:30:38','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:38','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway20','1.0','1969-12-31 23:59:59'),('newgateway2@scigap',NULL,NULL,'2017-06-16 15:30:37','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:37','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway2','1.0','1969-12-31 23:59:59'),('newgateway3@scigap',NULL,NULL,'2017-06-16 15:30:38','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:38','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway3','1.0','1969-12-31 23:59:59'),('newgateway4@scigap',NULL,'Sri Lanka','2017-06-16 15:30:39','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:39','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway4','1.0','1969-12-31 23:59:59'),('newgateway6@scigap',NULL,'Sri Lanka','2017-06-16 15:30:39','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:39','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway6','1.0','1969-12-31 23:59:59'),('newgateway7@scigap',NULL,'United States','2017-06-16 15:30:40','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:40','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgateway7','1.0','1969-12-31 23:59:59'),('newgtwy1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:40','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:40','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgtwy1','1.0','1969-12-31 23:59:59'),('newgtwy2@scigap',NULL,'Sri Lanka','2017-06-16 15:30:40','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:40','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgtwy2','1.0','1969-12-31 23:59:59'),('newgtwyportal1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:41','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:41','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newgtwyportal1','1.0','1969-12-31 23:59:59'),('newscigap16@scigap',NULL,'Sri Lanka','2017-06-16 15:30:41','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:41','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'newscigap16','1.0','1969-12-31 23:59:59'),('ngateway4@scigap',NULL,NULL,'2017-06-16 15:30:34','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:34','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'ngateway4','1.0','1969-12-31 23:59:59'),('pamidigs@seagrid',NULL,'United States','2017-06-16 15:26:10','Sudhakar','seagrid',NULL,'Indiana University','2017-06-16 15:26:10','Pamidighantam',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'pamidigs','1.0','1969-12-31 23:59:59'),('phygateway11@scigap',NULL,'Sri Lanka','2017-06-16 15:30:43','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:43','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway11','1.0','1969-12-31 23:59:59'),('phygateway12@scigap',NULL,'Sri Lanka','2017-06-16 15:30:43','Eroma','scigap',NULL,'IUU','2017-06-16 15:30:43','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway12','1.0','1969-12-31 23:59:59'),('phygateway1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:42','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:42','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway1','1.0','1969-12-31 23:59:59'),('phygateway20@scigap',NULL,'Sri Lanka','2017-06-16 15:30:44','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:44','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway20','1.0','1969-12-31 23:59:59'),('phygateway2@scigap',NULL,'Sri Lanka','2017-06-16 15:30:43','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:43','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway2','1.0','1969-12-31 23:59:59'),('phygateway3@scigap',NULL,'Sri Lanka','2017-06-16 15:30:44','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:44','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway3','1.0','1969-12-31 23:59:59'),('phygateway4@scigap',NULL,'Sri Lanka','2017-06-16 15:30:45','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:45','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway4','1.0','1969-12-31 23:59:59'),('phygateway5@scigap',NULL,'Sri Lanka','2017-06-16 15:30:45','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:45','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway5','1.0','1969-12-31 23:59:59'),('phygateway6@scigap',NULL,'Sri Lanka','2017-06-16 15:30:46','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:46','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway6','1.0','1969-12-31 23:59:59'),('phygateway7@scigap',NULL,'Sri Lanka','2017-06-16 15:30:46','Eroma','scigap',NULL,'IU','2017-06-16 15:30:46','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway7','1.0','1969-12-31 23:59:59'),('phygateway8@scigap',NULL,'Sri Lanka','2017-06-16 15:30:46','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:46','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway8','1.0','1969-12-31 23:59:59'),('phygateway9@scigap',NULL,'Sri Lanka','2017-06-16 15:30:47','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:47','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'phygateway9','1.0','1969-12-31 23:59:59'),('qiyang@scigap',NULL,NULL,'2017-06-16 15:30:54','Qiyang','scigap',NULL,'UCLA IDRE','2017-06-16 15:30:54','Hu',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'qiyang','1.0','1969-12-31 23:59:59'),('quinnrdev@seagrid',NULL,'US','2017-06-16 15:26:11','Ryan','seagrid',NULL,'Oklahoma Innovation Institute','2017-06-16 15:26:11','Quinn',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'quinnrdev','1.0','1969-12-31 23:59:59'),('rabhutta@scigap',NULL,'USA','2017-06-16 15:30:55','Rizwan','scigap',NULL,'Old Dominion University','2017-06-16 15:30:55','Bhutta',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'rabhutta','1.0','1969-12-31 23:59:59'),('scigap_admin@scigap',NULL,NULL,'2017-06-16 15:30:55','SciGaP ','scigap',NULL,NULL,'2017-06-16 15:30:55','Admin',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'scigap_admin','1.0','1969-12-31 23:59:59'),('scnakandala2@scigap',NULL,NULL,'2017-06-16 15:30:56','Supun','scigap',NULL,NULL,'2017-06-16 15:30:56','Nakandala',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'scnakandala2','1.0','1969-12-31 23:59:59'),('scnakandala456@scigap',NULL,NULL,'2017-06-16 15:30:56','Supun','scigap',NULL,NULL,'2017-06-16 15:30:56','Nakandala',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'scnakandala456','1.0','1969-12-31 23:59:59'),('scnakandala@seagrid',NULL,NULL,'2017-06-16 15:26:11','Supun','seagrid',NULL,NULL,'2017-06-16 15:26:11','Nakandala',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'scnakandala','1.0','1969-12-31 23:59:59'),('siugateway@scigap',NULL,'United States','2017-06-16 15:30:47','Eroma','scigap',NULL,'Indiana Univeristy','2017-06-16 15:30:47','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'siugateway','1.0','1969-12-31 23:59:59'),('smarru@scigap',NULL,NULL,'2017-06-16 15:30:57','Suresh','scigap',NULL,NULL,'2017-06-16 15:30:57','Marru',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'smarru','1.0','1969-12-31 23:59:59'),('smarru@seagrid',NULL,NULL,'2017-06-16 15:26:12','Suresh','seagrid',NULL,NULL,'2017-06-16 15:26:12','Marru',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'smarru','1.0','1969-12-31 23:59:59'),('spamidig@scigap',NULL,NULL,'2017-06-16 15:30:57','Sudhakar','scigap',NULL,NULL,'2017-06-16 15:30:57','Pamidighantam',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'spamidig','1.0','1969-12-31 23:59:59'),('spamidig@seagrid',NULL,'USA','2017-06-16 15:26:12','Sudhakar','seagrid',NULL,'Indiana University','2017-06-16 15:26:12','Pamidighantam',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'spamidig','1.0','1969-12-31 23:59:59'),('supunarunoda@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:04','Supun','seagrid',NULL,'Student','2017-06-16 15:26:04','Arunoda',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'supunarunoda','1.0','1969-12-31 23:59:59'),('sureshgwytest@scigap',NULL,NULL,'2017-06-16 15:30:58','Suresh','scigap',NULL,NULL,'2017-06-16 15:30:58','Marru',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'sureshgwytest','1.0','1969-12-31 23:59:59'),('test1234@scigap',NULL,NULL,'2017-06-16 15:30:59','Supun','scigap',NULL,NULL,'2017-06-16 15:30:59','Nakandala',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'test1234','1.0','1969-12-31 23:59:59'),('test123@scigap',NULL,NULL,'2017-06-16 15:30:58','Supun','scigap',NULL,NULL,'2017-06-16 15:30:58','Nakandala',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'test123','1.0','1969-12-31 23:59:59'),('testgateway1@scigap',NULL,'Sri Lanka','2017-06-16 15:30:48','Eroma','scigap',NULL,NULL,'2017-06-16 15:30:48','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'testgateway1','1.0','1969-12-31 23:59:59'),('testgw1@scigap',NULL,NULL,'2017-06-16 15:30:59','Suresh','scigap',NULL,NULL,'2017-06-16 15:30:59','Marru',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'testgw1','1.0','1969-12-31 23:59:59'),('testuser1@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:04','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:04','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'testuser1','1.0','1969-12-31 23:59:59'),('testuser2@seagrid',NULL,'United States','2017-06-16 15:26:05','Eroma','seagrid',NULL,'Indiana Univeristy','2017-06-16 15:26:05','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'testuser2','1.0','1969-12-31 23:59:59'),('testuser3@seagrid',NULL,'Sri Lanka','2017-06-16 15:26:05','Eroma','seagrid',NULL,NULL,'2017-06-16 15:26:05','Abeysinghe',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'testuser3','1.0','1969-12-31 23:59:59'),('tilaks@scigap',NULL,'United States of America','2017-06-16 15:31:00','Sneha','scigap',NULL,'Indiana University Bloomington','2017-06-16 15:31:00','Tilak',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'tilaks','1.0','1969-12-31 23:59:59'),('varjas@scigap',NULL,NULL,'2017-06-16 15:31:01','Christopher','scigap',NULL,NULL,'2017-06-16 15:31:01','Varjas',NULL,NULL,NULL,NULL,NULL,'ACTIVE',NULL,'varjas','1.0','1969-12-31 23:59:59');
/*!40000 ALTER TABLE `USER_PROFILE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PROFILE_EMAIL`
--

DROP TABLE IF EXISTS `USER_PROFILE_EMAIL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PROFILE_EMAIL` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) DEFAULT NULL,
  `EMAILS` varchar(255) DEFAULT NULL,
  KEY `AIRAVATA_INTERNAL_USER_ID` (`AIRAVATA_INTERNAL_USER_ID`),
  CONSTRAINT `USER_PROFILE_EMAIL_ibfk_1` FOREIGN KEY (`AIRAVATA_INTERNAL_USER_ID`) REFERENCES `USER_PROFILE` (`AIRAVATA_INTERNAL_USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PROFILE_EMAIL`
--

LOCK TABLES `USER_PROFILE_EMAIL` WRITE;
/*!40000 ALTER TABLE `USER_PROFILE_EMAIL` DISABLE KEYS */;
INSERT INTO `USER_PROFILE_EMAIL` VALUES ('april16@seagrid','eroma.abeysinghe@gmail.com'),('dseagrid100@seagrid','eabeysin@iu.edu'),('dseagrid101@seagrid','eabeysin@iu.edu'),('dseagrid11@seagrid','eroma.abeysinghe@gmail.com'),('dseagrid200@seagrid','eroma.abeysinghe@gmail.com'),('dseagrid300@seagrid','eroma.abeysinghe@gmail.com'),('dseagrid5@seagrid','eroma.abeysinghe@gmail.com'),('dseagrid500@seagrid','eroma.abeysinghe@gmail.com'),('dseagrid6@seagrid','eroma.abeysinghe@gmail.com'),('dseagrid7@seagrid','eroma.abeysinghe@gmail.com'),('dsgrid1@seagrid','eabeysin@iu.edu'),('dshare1@seagrid','eroma.abeysinghe@gmail.com'),('dshare2@seagrid','eroma.abeysinghe@gmail.com'),('dshare3@seagrid','eroma.abeysinghe@gmail.com'),('dshare5@seagrid','eroma.abeysinghe@gmail.com'),('datas1@seagrid','eroma.abeysinghe@gmail.com'),('dev1eroma2017@seagrid','eroma.abeysinghe@gmail.com'),('devero2017@seagrid','eroma.abeysinghe@gmail.com'),('deveroma2017@seagrid','eroma.abeysinghe@gmail.com'),('devseagrid1@seagrid','eroma.abeysinghe@gmail.com'),('devseagrid10@seagrid','eabeysin@iu.edu'),('devtest1@seagrid','eroma.abeysinghe@gmail.com'),('elena123@seagrid','eroma.abeysinghe@gmail.com'),('eroma2017@seagrid','eroma.abeysinghe@gmail.com'),('john123@seagrid','eroma.abeysinghe@gmail.com'),('supunarunoda@seagrid','supunarunoda.13@cse.mrt.ac.lk'),('testuser1@seagrid','eroma.abeysinghe@gmail.com'),('testuser2@seagrid','eabeysin@iu.edu'),('testuser3@seagrid','eroma.abeysinghe@gmail.com'),('anujbhan@seagrid','bhandar.anuj@gmail.com'),('anujmb@seagrid','bhandar.anuj@gmail.com'),('goshenoy@seagrid','goshenoy@indiana.edu'),('junwang@seagrid','wang208@iu.edu'),('marcus@seagrid','machrist@iu.edu'),('marcus-user@seagrid','machrist@iu.edu'),('marcus-user2@seagrid','machrist@iu.edu'),('marcus-user3@seagrid','machrist@iu.edu'),('marcus-user4@seagrid','machrist@iu.edu'),('pamidigs@seagrid','pamidigs@iu.edu'),('quinnrdev@seagrid','ryan@oii.org'),('scnakandala@seagrid','supun.nakandala@gmail.com'),('smarru@seagrid','smarru@iu.edu'),('spamidig@seagrid','pamidigs@iu.edu'),('cdscigap1@scigap','eroma.abeysinghe@gmail.com'),('checkscigap1@scigap','eroma.abeysinghe@gmail.com'),('checkscigap2@scigap','eroma.abeysinghe@gmail.com'),('checkscigap3@scigap','thejaka.amila@gmail.com'),('dampoi@scigap','dam@yopmail.com'),('demogyadm@scigap','smarru@iu.edu'),('devscigap1@scigap','eroma.abeysinghe@gmail.com'),('devscigap2@gmail.com@scigap','eabeysin@iu.edu'),('devscigap3@scigap','eroma.abeysinghe@gmail.com'),('devond3~@scigap','devondillon333@gmail.com'),('enggateway@scigap','eroma.abeysinghe@gmail.com'),('enggateway100@scigap','thejaka.amila@gmail.com'),('enggateway16@scigap','eroma.abeysinghe@gmail.com'),('enggateway2015@scigap','eroma.abeysinghe@gmail.com'),('enggateway2016@scigap','eroma.abeysinghe@gmail.com'),('engineergateway1@scigap','eroma.abeysinghe@gmail.com'),('eroscigap@scigap','eabeysin@iu.edu'),('eroma1802@scigap','eroma.abeysinghe@gmail.com'),('eroma2016@scigap','eroma.abeysinghe@gmail.com'),('eroma2017@scigap','eroma.abeysinghe@gmail.com'),('eromagateway1@scigap','eabeysin@iu.edu'),('eromagateway17@scigap','eabeysin@iu.edu'),('eromapga@scigap','eabeysin@iu.edu'),('eromasgrc@scigap','eroma.abeysinghe@gmail.com'),('gateway1@scigap','eroma.abeysinghe@gmail.com'),('gatewaypi1@scigap','eroma.abeysinghe@gmail.com'),('gatewayr1@scigap','eroma.abeysinghe@gmail.com'),('jsgateways1@scigap','eabeysin@iu.edu'),('ngateway4@scigap','eroma.abeysinghe@gmail.com'),('ndoshi28@scigap','nidoshi@indiana.edu'),('newgateway1@scigap','eroma.abeysinghe@gmail.com'),('newgateway10@scigap','eabeysin@iu.edu'),('newgateway100@scigap','eroma.abeysinghe@gmail.com'),('newgateway11@scigap','eabeysin@iu.edu'),('newgateway111@scigap','eroma.abeysinghe@gmail.com'),('newgateway2@scigap','eroma.abeysinghe@gmail.com'),('newgateway20@scigap','eabeysin@iu.edu'),('newgateway3@scigap','eroma.abeysinghe@gmail.com'),('newgateway4@scigap','eroma.abeysinghe@gmail.com'),('newgateway6@scigap','eroma.abeysinghe@gmail.com'),('newgateway7@scigap','eabeysin@iu.edu'),('newgtwy1@scigap','eroma.abeysinghe@gmail.com'),('newgtwy2@scigap','eroma.abeysinghe@gmail.com'),('newgtwyportal1@scigap','eroma.abeysinghe@gmail.com'),('newscigap16@scigap','eroma.abeysinghe@gmail.com'),('phygateway1@scigap','eroma.abeysinghe@gmail.com'),('phygateway11@scigap','eroma.abeysinghe@gmail.com'),('phygateway12@scigap','eroma.abeysinghe@gmail.com'),('phygateway2@scigap','eroma.abeysinghe@gmail.com'),('phygateway20@scigap','eroma.abeysinghe@gmail.com'),('phygateway3@scigap','eroma.abeysinghe@gmail.com'),('phygateway4@scigap','eroma.abeysinghe@gmail.com'),('phygateway5@scigap','eroma.abeysinghe@gmail.com'),('phygateway6@scigap','eroma.abeysinghe@gmail.com'),('phygateway7@scigap','eroma.abeysinghe@gmail.com'),('phygateway8@scigap','eroma.abeysinghe@gmail.com'),('phygateway9@scigap','eroma.abeysinghe@gmail.com'),('siugateway@scigap','eabeysin@iu.edu'),('testgateway1@scigap','eroma.abeysinghe@gmail.com'),('alaindomissy@scigap','alaindomissy@gmail.com'),('anujbhan@scigap','anujbhan@iu.edu'),('demousergwy@scigap','smarru@iu.edu'),('gatewaytest1@scigap','supun.nakandala@gmail.com'),('gemba1@scigap','supun.nakandala@gmail.com'),('goshenoy@scigap','goshenoy@indiana.edu'),('hellork@scigap','hellork@gmail.com'),('hhcorzo@scigap','cbi207214864@gmail.com'),('jsale37@scigap','jsale37@gmail.com'),('juxtapose@scigap','supun.nakandala@gmail.com'),('mamiller@scigap','mmiller@sdsc.edu'),('marcus@scigap','machrist@iu.edu'),('markperri@scigap','perrim@sonoma.edu'),('marpierc@scigap','marpierc@iu.edu'),('qiyang@scigap','huqy@idre.ucla.edu'),('rabhutta@scigap','rbhutta@odu.edu'),('scigap_admin@scigap','sgg@iu.edu'),('scnakandala2@scigap','supun.nakandala@gmail.com'),('scnakandala456@scigap','supun.nakandala@gmail.com'),('smarru@scigap','smarru@iu.edu'),('spamidig@scigap','pamidigs@iu.edu'),('sureshgwytest@scigap','smarru@iu.edu'),('test123@scigap','supun.nakandala@gmail.com'),('test1234@scigap','supun.nakandala@gmail.com'),('testgw1@scigap','smarru@iu.edu'),('tilaks@scigap','sneha.tilak26@gmail.com'),('varjas@scigap','cvarjas@gmail.com'),('admin@seagrid','machrist@iu.edu');
/*!40000 ALTER TABLE `USER_PROFILE_EMAIL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PROFILE_LABELED_URI`
--

DROP TABLE IF EXISTS `USER_PROFILE_LABELED_URI`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PROFILE_LABELED_URI` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) DEFAULT NULL,
  `LABELED_URI` varchar(255) DEFAULT NULL,
  KEY `AIRAVATA_INTERNAL_USER_ID` (`AIRAVATA_INTERNAL_USER_ID`),
  CONSTRAINT `USER_PROFILE_LABELED_URI_ibfk_1` FOREIGN KEY (`AIRAVATA_INTERNAL_USER_ID`) REFERENCES `USER_PROFILE` (`AIRAVATA_INTERNAL_USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PROFILE_LABELED_URI`
--

LOCK TABLES `USER_PROFILE_LABELED_URI` WRITE;
/*!40000 ALTER TABLE `USER_PROFILE_LABELED_URI` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_PROFILE_LABELED_URI` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PROFILE_NATIONALITY`
--

DROP TABLE IF EXISTS `USER_PROFILE_NATIONALITY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PROFILE_NATIONALITY` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) DEFAULT NULL,
  `NATIONALITY` varchar(255) DEFAULT NULL,
  KEY `AIRAVATA_INTERNAL_USER_ID` (`AIRAVATA_INTERNAL_USER_ID`),
  CONSTRAINT `USER_PROFILE_NATIONALITY_ibfk_1` FOREIGN KEY (`AIRAVATA_INTERNAL_USER_ID`) REFERENCES `USER_PROFILE` (`AIRAVATA_INTERNAL_USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PROFILE_NATIONALITY`
--

LOCK TABLES `USER_PROFILE_NATIONALITY` WRITE;
/*!40000 ALTER TABLE `USER_PROFILE_NATIONALITY` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_PROFILE_NATIONALITY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PROFILE_PHONE`
--

DROP TABLE IF EXISTS `USER_PROFILE_PHONE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `USER_PROFILE_PHONE` (
  `AIRAVATA_INTERNAL_USER_ID` varchar(255) DEFAULT NULL,
  `PHONES` varchar(255) DEFAULT NULL,
  KEY `AIRAVATA_INTERNAL_USER_ID` (`AIRAVATA_INTERNAL_USER_ID`),
  CONSTRAINT `USER_PROFILE_PHONE_ibfk_1` FOREIGN KEY (`AIRAVATA_INTERNAL_USER_ID`) REFERENCES `USER_PROFILE` (`AIRAVATA_INTERNAL_USER_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PROFILE_PHONE`
--

LOCK TABLES `USER_PROFILE_PHONE` WRITE;
/*!40000 ALTER TABLE `USER_PROFILE_PHONE` DISABLE KEYS */;
INSERT INTO `USER_PROFILE_PHONE` VALUES ('april16@seagrid','773335102'),('april16@seagrid','773335102'),('dseagrid100@seagrid','3174802420'),('dseagrid100@seagrid','3174802420'),('dseagrid101@seagrid','3174802420'),('dseagrid101@seagrid','3174802420'),('dseagrid11@seagrid','773335102'),('dseagrid11@seagrid','773335102'),('dseagrid200@seagrid','773335102'),('dseagrid200@seagrid','773335102'),('dseagrid300@seagrid','773335102'),('dseagrid300@seagrid','773335102'),('dseagrid5@seagrid','773335102'),('dseagrid5@seagrid','773335102'),('dseagrid500@seagrid','773335102'),('dseagrid500@seagrid','773335102'),('dseagrid6@seagrid','773335102'),('dseagrid6@seagrid','773335102'),('dseagrid7@seagrid','773335102'),('dseagrid7@seagrid','773335102'),('dsgrid1@seagrid','3174802420'),('dsgrid1@seagrid','3174802420'),('dshare1@seagrid','773335102'),('dshare1@seagrid','773335102'),('dshare2@seagrid','773335102'),('dshare2@seagrid','773335102'),('dshare3@seagrid','773335102'),('dshare3@seagrid','773335102'),('dshare5@seagrid','773335102'),('dshare5@seagrid','773335102'),('datas1@seagrid','773335102'),('datas1@seagrid','773335102'),('dev1eroma2017@seagrid','3174802420'),('dev1eroma2017@seagrid','3174802420'),('devero2017@seagrid','773335102'),('devero2017@seagrid','773335102'),('deveroma2017@seagrid','773335102'),('deveroma2017@seagrid','773335102'),('devseagrid1@seagrid','773335102'),('devseagrid1@seagrid','773335102'),('devseagrid10@seagrid','3174802420'),('devseagrid10@seagrid','3174802420'),('devtest1@seagrid','773335102'),('devtest1@seagrid','773335102'),('elena123@seagrid','773335102'),('elena123@seagrid','773335102'),('eroma2017@seagrid','773335102'),('eroma2017@seagrid','773335102'),('john123@seagrid','773335102'),('john123@seagrid','773335102'),('supunarunoda@seagrid','+94712493575'),('supunarunoda@seagrid','+94712493575'),('testuser1@seagrid','773335102'),('testuser1@seagrid','773335102'),('testuser2@seagrid','3174802420'),('testuser2@seagrid','3174802420'),('testuser3@seagrid','773335102'),('testuser3@seagrid','773335102'),('marcus-user@seagrid','8128556827'),('marcus-user2@seagrid','8128556827'),('pamidigs@seagrid','2173981063'),('pamidigs@seagrid','2173981063'),('quinnrdev@seagrid','918-863-8705'),('quinnrdev@seagrid','918-510-6251'),('spamidig@seagrid','2173981063'),('spamidig@seagrid','2173981063'),('cdscigap1@scigap','773335102'),('cdscigap1@scigap','773335102'),('checkscigap1@scigap','773335102'),('checkscigap1@scigap','773335102'),('checkscigap2@scigap','773335102'),('checkscigap2@scigap','773335102'),('checkscigap3@scigap','3174802420'),('checkscigap3@scigap','3174802420'),('devscigap1@scigap','773335102'),('devscigap1@scigap','773335102'),('devscigap2@gmail.com@scigap','3174802420'),('devscigap2@gmail.com@scigap','3174802420'),('devscigap3@scigap','773335102'),('devscigap3@scigap','773335102'),('enggateway@scigap','773335102'),('enggateway@scigap','773335102'),('enggateway100@scigap','3174802420'),('enggateway100@scigap','3174802420'),('enggateway16@scigap','773335102'),('enggateway16@scigap','773335102'),('enggateway2015@scigap','773335102'),('enggateway2015@scigap','773335102'),('enggateway2016@scigap','773335102'),('enggateway2016@scigap','773335102'),('engineergateway1@scigap','773335102'),('engineergateway1@scigap','773335102'),('eroscigap@scigap','3174802420'),('eroscigap@scigap','3174802420'),('eroma2017@scigap','3174802420'),('eroma2017@scigap','3174802420'),('eromagateway1@scigap','3174802420'),('eromagateway1@scigap','3174802420'),('eromagateway17@scigap','3174802420'),('eromagateway17@scigap','3174802420'),('eromapga@scigap','3174802420'),('eromapga@scigap','3174802420'),('gateway1@scigap','773335102'),('gateway1@scigap','773335102'),('gatewaypi1@scigap','773335102'),('gatewaypi1@scigap','773335102'),('gatewayr1@scigap','773335102'),('gatewayr1@scigap','773335102'),('jsgateways1@scigap','3174802420'),('jsgateways1@scigap','3174802420'),('ngateway4@scigap','3174802420'),('ngateway4@scigap','3174802420'),('newgateway1@scigap','3174802420'),('newgateway1@scigap','3174802420'),('newgateway10@scigap','3174802420'),('newgateway10@scigap','3174802420'),('newgateway100@scigap','3174802420'),('newgateway100@scigap','3174802420'),('newgateway11@scigap','3174802420'),('newgateway11@scigap','3174802420'),('newgateway2@scigap','3174802420'),('newgateway2@scigap','3174802420'),('newgateway20@scigap','3174802420'),('newgateway20@scigap','3174802420'),('newgateway3@scigap','3174802420'),('newgateway3@scigap','3174802420'),('newgateway4@scigap','773335102'),('newgateway4@scigap','773335102'),('newgateway6@scigap','773335102'),('newgateway6@scigap','773335102'),('newgateway7@scigap','3174802420'),('newgateway7@scigap','3174802420'),('newgtwy1@scigap','773335102'),('newgtwy1@scigap','773335102'),('newgtwy2@scigap','773335102'),('newgtwy2@scigap','773335102'),('newgtwyportal1@scigap','773335102'),('newgtwyportal1@scigap','773335102'),('newscigap16@scigap','773335102'),('newscigap16@scigap','773335102'),('phygateway1@scigap','773335102'),('phygateway1@scigap','773335102'),('phygateway11@scigap','773335102'),('phygateway11@scigap','773335102'),('phygateway12@scigap','773335102'),('phygateway12@scigap','773335102'),('phygateway2@scigap','773335102'),('phygateway2@scigap','773335102'),('phygateway20@scigap','773335102'),('phygateway20@scigap','773335102'),('phygateway3@scigap','773335102'),('phygateway3@scigap','773335102'),('phygateway4@scigap','773335102'),('phygateway4@scigap','773335102'),('phygateway5@scigap','773335102'),('phygateway5@scigap','773335102'),('phygateway6@scigap','773335102'),('phygateway6@scigap','773335102'),('phygateway7@scigap','773335102'),('phygateway7@scigap','773335102'),('phygateway8@scigap','773335102'),('phygateway8@scigap','773335102'),('phygateway9@scigap','773335102'),('phygateway9@scigap','773335102'),('siugateway@scigap','3174802420'),('siugateway@scigap','3174802420'),('testgateway1@scigap','773335102'),('testgateway1@scigap','773335102'),('alaindomissy@scigap','619-884-5450'),('hhcorzo@scigap','3348442522'),('hhcorzo@scigap','3348442522'),('markperri@scigap','707-664-2440'),('rabhutta@scigap','7576833586'),('rabhutta@scigap','7576632965'),('tilaks@scigap','8123692099');
/*!40000 ALTER TABLE `USER_PROFILE_PHONE` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-22 13:55:15
